package com.example.example_retrofit_android.data.repository

import com.example.example_retrofit_android.data.api.ProductApi
import com.example.example_retrofit_android.data.model.ProductModel
import retrofit2.Response

class ProductRepository(private val api: ProductApi) {
    suspend fun getProducts(): Response<List<ProductModel>> = api.getProducts()
}