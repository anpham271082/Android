package com.example.example_retrofit_android.data.model

data class ProductModel(
    val id: Int,
    val name: String,
    val price: Double
)