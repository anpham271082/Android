package com.example.example_retrofit_android.di

import com.example.example_retrofit_android.data.api.AuthApi
import com.example.example_retrofit_android.data.api.ProductApi
import com.example.example_retrofit_android.data.repository.AuthRepository
import com.example.example_retrofit_android.data.repository.ProductRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
object RepositoryModule {

    @Provides
    fun provideAuthRepository(api: AuthApi): AuthRepository = AuthRepository(api)

    @Provides
    fun provideProductRepository(api: ProductApi): ProductRepository = ProductRepository(api)
}