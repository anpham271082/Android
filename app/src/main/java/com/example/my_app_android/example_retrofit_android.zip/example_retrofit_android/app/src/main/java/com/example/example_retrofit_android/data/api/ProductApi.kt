package com.example.example_retrofit_android.data.api

import com.example.example_retrofit_android.data.model.ProductModel
import retrofit2.Response
import retrofit2.http.GET

interface ProductApi {
    @GET("products")
    suspend fun getProducts(): Response<List<ProductModel>>
}