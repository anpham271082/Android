package com.example.example_retrofit_android.data.model

data class LoginModel(
    val username: String,
    val password: String
)
data class LoginTokenModel(
    val token: String
)