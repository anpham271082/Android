package com.example.example_retrofit_android.di

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import jakarta.inject.Qualifier
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import dagger.hilt.components.SingletonComponent

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class ServerAuth
@Qualifier @Retention(AnnotationRetention.BINARY)
annotation class ServerProduct

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @ServerAuth
    @Provides
    fun provideAuthRetrofit(): Retrofit =
        Retrofit.Builder()
            .baseUrl("https://auth.example.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

    @ServerProduct
    @Provides
    fun provideProductRetrofit(): Retrofit =
        Retrofit.Builder()
            .baseUrl("https://product.example.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
}