package com.example.example_retrofit_android.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.example_retrofit_android.data.model.ProductModel
import com.example.example_retrofit_android.data.repository.AuthRepository
import com.example.example_retrofit_android.data.repository.ProductRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import jakarta.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

@HiltViewModel
class MainViewModel @Inject constructor(
    private val authRepo: AuthRepository,
    private val productRepo: ProductRepository
): ViewModel() {

    private val _tokenState = MutableStateFlow<String?>(null)
    val tokenState: StateFlow<String?> = _tokenState

    private val _productsState = MutableStateFlow<List<ProductModel>>(emptyList())
    val productsState: StateFlow<List<ProductModel>> = _productsState

    fun login(user: String, pass: String) = viewModelScope.launch {
        authRepo.login(user, pass).body()?.let {
            _tokenState.value = it.token
        }
    }

    fun fetchProducts() = viewModelScope.launch {
        productRepo.getProducts().body()?.let {
            _productsState.value = it
        }
    }
}