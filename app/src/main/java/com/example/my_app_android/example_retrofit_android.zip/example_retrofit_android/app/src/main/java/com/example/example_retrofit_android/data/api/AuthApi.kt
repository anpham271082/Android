package com.example.example_retrofit_android.data.api

import com.example.example_retrofit_android.data.model.LoginModel
import com.example.example_retrofit_android.data.model.LoginTokenModel
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

interface AuthApi {
    @POST("login")
    suspend fun login(@Body request: LoginModel): Response<LoginTokenModel>
}