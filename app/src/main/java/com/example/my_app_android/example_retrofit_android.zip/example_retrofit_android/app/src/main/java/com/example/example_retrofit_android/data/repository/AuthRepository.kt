package com.example.example_retrofit_android.data.repository

import com.example.example_retrofit_android.data.api.AuthApi
import com.example.example_retrofit_android.data.model.LoginModel
import com.example.example_retrofit_android.data.model.LoginTokenModel
import retrofit2.Response

class AuthRepository(private val api: AuthApi) {
    suspend fun login(user: String, pass: String): Response<LoginTokenModel> =
        api.login(LoginModel(user, pass))
}