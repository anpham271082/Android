package com.example.example_retrofit_android

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.example_retrofit_android.ui.theme.Example_retrofit_androidTheme
import com.example.example_retrofit_android.viewmodel.MainViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val vm: MainViewModel = hiltViewModel()
            val token by vm.tokenState.collectAsState()
            val products by vm.productsState.collectAsState()

            Column(Modifier.padding(16.dp)) {
                var user by remember { mutableStateOf("") }
                var pass by remember { mutableStateOf("") }

                OutlinedTextField(user, { user = it }, label = { Text("Username") })
                OutlinedTextField(pass, { pass = it }, label = { Text("Password") })

                Spacer(Modifier.height(8.dp))
                Button(onClick = { vm.login(user, pass) }) {
                    Text("Login")
                }
                token?.let {
                    Text("Token: $it", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { vm.fetchProducts() }) {
                        Text("Fetch Products")
                    }
                }
                LazyColumn {
                    items(products.size) { idx ->
                        val p = products[idx]
                        Text("${p.name}: \$${p.price}", Modifier.padding(4.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    Example_retrofit_androidTheme {
        Greeting("Android")
    }
}