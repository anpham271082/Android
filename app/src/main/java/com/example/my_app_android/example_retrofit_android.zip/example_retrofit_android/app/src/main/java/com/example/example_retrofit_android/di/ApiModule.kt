package com.example.example_retrofit_android.di

import com.example.example_retrofit_android.data.api.AuthApi
import com.example.example_retrofit_android.data.api.ProductApi
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit


@Module
@InstallIn(SingletonComponent::class)
object ApiModule {

    @Provides
    fun provideAuthApi(@ServerAuth retrofit: Retrofit): AuthApi =
        retrofit.create(AuthApi::class.java)

    @Provides
    fun provideProductApi(@ServerProduct retrofit: Retrofit): ProductApi =
        retrofit.create(ProductApi::class.java)
}